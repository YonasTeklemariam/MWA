angular.module("meanSoccer").factory("TeamsDataFactory", TeamsDataFactory);

function TeamsDataFactory($http) {
  return {
    getAll: getAllTeams,
    getOne: getOneTeam,
  };

  function getAllTeams() {
    return $http.get("/api/premierLeague").then(complete).catch(failed);
  }
  function getOneTeam(teamId) {
    return $http
      .get("/api/premierLeague/" + teamId)
      .then(complete)
      .catch(failed);
  }
  function complete(response) {
    return response.data;
  }
  function failed(error) {
    return error.status.statusText;
  }
}
