angular.module("meanSoccer").controller("TeamsController", TeamsController);
function TeamsController(TeamsDataFactory) {
  const vm = this;
  vm.title = "Mean Soccer App";
  TeamsDataFactory.getAll().then(function (response) {
    vm.teams = response;
  });
}
