angular
  .module("meanSoccer")
  .controller("TeamMembersController", TeamMembersController);
function TeamMembersController(TeamsDataFactory, $routeParams) {
  const vm = this;
  const teamId = $routeParams.teamId;
  TeamsDataFactory.getOne(teamId).then(function (response) {
    vm.team = response;
  });
}
