angular.module("myProperApp").controller("boredController", boredController);

function boredController($http) {
  var vm = this;
  $http.get("https://www.boredapi.com/api/activity").then(function (response) {
    console.log(response.data.bored);
    vm.bored = response.data;
  });
}
